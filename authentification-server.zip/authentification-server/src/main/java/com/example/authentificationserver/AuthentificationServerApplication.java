package com.example.authentificationserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthentificationServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthentificationServerApplication.class, args);
	}

}
